import static org.junit.Assert.*;
import org.junit.Test;

public class TestArrayDeque1B {

}
